﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_SalesDatabase.Data
{
    static class Configuration
    {
        internal static string ConnectionString = @"Server=DESKTOP-TU655AE\SQLEXPRESS;Database=Hospital;Integrated Security=True;";
    }
}
