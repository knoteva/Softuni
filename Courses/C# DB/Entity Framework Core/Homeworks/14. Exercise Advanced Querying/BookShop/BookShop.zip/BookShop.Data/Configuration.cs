﻿namespace BookShop.Data
{
    internal class Configuration
    {
        //internal static string ConnectionString => @"Server=DESKTOP-TU655A\SQLEXPRESS;Database=BookShop;Integrated Security=True;";

        internal static string ConnectionString = @"Server=DESKTOP-TU655AE\SQLEXPRESS;Database=BookShop;Integrated Security=True;";

    }
}
