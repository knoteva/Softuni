﻿namespace MiniORM
{
	// TODO: Create your ChangeTracker class here.
}