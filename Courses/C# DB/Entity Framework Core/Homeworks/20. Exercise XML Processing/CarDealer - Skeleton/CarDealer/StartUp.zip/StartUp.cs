﻿using AutoMapper;
using CarDealer.Data;
using CarDealer.Dtos.Export;
using CarDealer.Dtos.Import;
using CarDealer.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Mapper.Initialize(x =>
            {
                x.AddProfile<CarDealerProfile>();
            });

            var context = new CarDealerContext();
            Console.WriteLine(GetSalesWithAppliedDiscount(context));

        }
        public static string GetSalesWithAppliedDiscount(CarDealerContext context)
        {

            var sales = context.Sales
                .Select(e => new ExportSalesWithAppliedDiscountDto
                {
                    Car = new ExportCarsAttributeDto
                    {
                        Make = e.Car.Make,
                        Model = e.Car.Model,
                        TravelledDistance = e.Car.TravelledDistance
                    },
                    Discount = e.Discount,
                    CustomerName = e.Customer.Name,
                    Price = e.Car.PartCars.Sum(p => p.Part.Price),
                    PriceWithDiscount = ((e.Car.PartCars.Sum(p => p.Part.Price) * (1 - e.Discount / 100))).ToString().TrimEnd('0'),
                })
                .ToArray();

            XmlSerializer serializer = new XmlSerializer(typeof(ExportSalesWithAppliedDiscountDto[]),
                new XmlRootAttribute("sales"));

            StringBuilder sb = new StringBuilder();

            XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
            ns.Add("", "");

            serializer.Serialize(new StringWriter(sb), sales, ns);

            return sb.ToString();
        }
    }
}