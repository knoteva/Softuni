﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
    static class Configuration
    {
        internal static string ConnectionString = @"Server=DESKTOP-TU655AE\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;";
    }
}
