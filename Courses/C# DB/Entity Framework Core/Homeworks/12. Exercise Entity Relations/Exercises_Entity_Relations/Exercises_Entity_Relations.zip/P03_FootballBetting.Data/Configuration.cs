﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data
{
    static class Configuration
    {
        internal static string ConnectionString = @"Server=DESKTOP-TU655AE\SQLEXPRESS;Database=FootballBetting;Integrated Security=True;";
    }
}
