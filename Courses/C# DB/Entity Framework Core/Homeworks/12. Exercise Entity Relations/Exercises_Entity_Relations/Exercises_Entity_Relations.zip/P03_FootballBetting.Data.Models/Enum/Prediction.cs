﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data.Models.Enum
{
    public enum Prediction
    {
        Win = 1,
        Draw = 0,
        Lost = -1
    }
}
