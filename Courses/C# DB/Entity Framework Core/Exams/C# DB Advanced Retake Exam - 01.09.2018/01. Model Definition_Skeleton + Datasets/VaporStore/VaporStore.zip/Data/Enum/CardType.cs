﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VaporStore.Data.Enum
{
    public enum CardType
    {
        Debit = 0,
        Credit = 1,
    }
}
