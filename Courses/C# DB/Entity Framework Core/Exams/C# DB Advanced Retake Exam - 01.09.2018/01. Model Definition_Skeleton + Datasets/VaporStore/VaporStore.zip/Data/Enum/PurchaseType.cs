﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VaporStore.Data.Enum
{
    public enum  PurchaseType
    {
        Retail = 0,
        Digital = 1
    }
}
