﻿using _03.Ferrari.Core;
using System;

namespace _03.Ferrari
{
    public class Program
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();

        }
    }
}
