﻿using System;

namespace _05.BorderControl
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
