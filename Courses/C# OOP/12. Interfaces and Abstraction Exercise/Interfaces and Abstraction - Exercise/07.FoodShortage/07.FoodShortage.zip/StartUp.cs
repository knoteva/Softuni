﻿using _07.FoodShortage.Core;
using System;

namespace _07.FoodShortage
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
