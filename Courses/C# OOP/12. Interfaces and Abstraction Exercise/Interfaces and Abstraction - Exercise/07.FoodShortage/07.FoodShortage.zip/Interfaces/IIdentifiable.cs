﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07.FoodShortage.Interfaces
{
    public interface IIdentifiable
   {
        string Id { get; set; }
    }
}
