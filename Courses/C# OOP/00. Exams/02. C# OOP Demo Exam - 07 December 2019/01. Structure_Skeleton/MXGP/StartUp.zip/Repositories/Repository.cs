﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MXGP.Repositories
{
    class Repository
    {
    }
}
