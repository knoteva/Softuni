﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnimalCentre.Core
{
    public interface IEngine
    {
        void Run();
    }
}
