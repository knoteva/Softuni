﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViceCity.IO.Contracts
{
    interface IReader
    {
        string ReadLine();
    }
}
