﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViceCity.Core.Contracts
{
    interface IEngine
    {
        void Run();
    }
}
