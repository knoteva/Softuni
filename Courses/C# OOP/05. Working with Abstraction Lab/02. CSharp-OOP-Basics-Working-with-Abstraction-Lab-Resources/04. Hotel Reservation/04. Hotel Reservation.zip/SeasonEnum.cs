﻿namespace HotelReservation
{
    public enum Seasons
    {
        Spring = 2,
        Summer = 4,
        Autumn = 1,
        Winter = 3

    }
}
