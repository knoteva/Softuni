﻿namespace HotelReservation
{
    public enum Discounts
    {
        None = 0,
        SecondVisit = 10,
        VIP = 20

    }
}
