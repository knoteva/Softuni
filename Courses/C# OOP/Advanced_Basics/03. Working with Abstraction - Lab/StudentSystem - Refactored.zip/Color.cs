﻿namespace P03_StudentSystem
{
    public enum Color
    {
        Unknown = 0,
        Red = 1,
        Purple = 2,
        Yellow = 3,
        Blue = 4,
    }
}
