﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Wild_Farm.Animals.Mammals.Contatcs
{
    public interface IMammal
    {
        string LivingRegion { get; }
    }
}
