﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Wild_Farm.Animals.Mammals.Felines.Contacts
{
   public interface IFeline
    {
        string Breed { get; }
    }
}
