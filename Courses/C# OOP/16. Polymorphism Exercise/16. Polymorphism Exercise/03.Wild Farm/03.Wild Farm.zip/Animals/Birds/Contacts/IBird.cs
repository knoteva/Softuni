﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Wild_Farm.Animals.Birds.Contacts
{
    public interface IBird
    {
        double WingSize { get; }
    }
}
