﻿using _03.Wild_Farm.Core;
using System;

namespace _03.Wild_Farm
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();

        }
    }
}
