﻿using _01._Vehicles.Core;
using System;

namespace _01._Vehicles
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
