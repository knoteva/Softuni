﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.Telephony.Interfaces
{
    public interface ICallable
    {
        string Call(string phoneNumber);
    }
}
