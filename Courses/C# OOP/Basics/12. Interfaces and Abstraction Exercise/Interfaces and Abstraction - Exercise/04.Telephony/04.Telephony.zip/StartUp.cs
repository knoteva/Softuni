﻿using _04.Telephony.Core;
using System;

namespace _04.Telephony
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
