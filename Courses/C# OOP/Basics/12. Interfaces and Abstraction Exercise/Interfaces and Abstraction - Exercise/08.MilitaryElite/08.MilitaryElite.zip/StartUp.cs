﻿using _08.MilitaryElite.Core;
using System;

namespace _08.MilitaryElite
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
