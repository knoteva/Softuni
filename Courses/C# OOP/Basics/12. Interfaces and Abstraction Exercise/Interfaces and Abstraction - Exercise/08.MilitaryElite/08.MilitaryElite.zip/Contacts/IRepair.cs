﻿namespace _08.MilitaryElite.Contacts
{
    public interface IRepair
    {
        string PartName { get; }
        int HoursWorked { get; }
    }
}