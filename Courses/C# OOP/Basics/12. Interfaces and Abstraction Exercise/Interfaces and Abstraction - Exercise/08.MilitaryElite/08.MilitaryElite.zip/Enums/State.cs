﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _08.MilitaryElite.Enums
{
    public enum State
    {
        inProgress = 1,
        Finished = 2
    }
}
