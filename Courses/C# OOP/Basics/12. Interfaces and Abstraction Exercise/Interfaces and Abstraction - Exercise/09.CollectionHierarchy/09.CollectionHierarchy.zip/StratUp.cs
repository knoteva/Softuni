﻿using _09.CollectionHierarchy.Core;
using System;

namespace _09.CollectionHierarchy
{
   public class StratUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
