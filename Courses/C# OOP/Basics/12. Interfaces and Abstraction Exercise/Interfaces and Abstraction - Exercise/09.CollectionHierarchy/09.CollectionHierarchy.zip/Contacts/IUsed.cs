﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _09.CollectionHierarchy.Contacts
{
    public interface IUsed
    {
        int Used { get; }
    }
}
