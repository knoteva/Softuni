﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cars.Interfaces
{
    public interface IElectricCar
    {
        int Battery { get; }
    }
}
