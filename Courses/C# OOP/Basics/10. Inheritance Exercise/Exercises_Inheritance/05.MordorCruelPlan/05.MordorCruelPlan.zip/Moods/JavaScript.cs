﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05.MordorCruelPlan.Moods
{
    public class JavaScript : Mood
    {
        public override string Name => "JavaScript";
    }
}
