﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05.MordorCruelPlan.Moods
{
    public class Angry : Mood
    {
        public override string Name => "Angry";
    }
}
