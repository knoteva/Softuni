﻿using _05.MordorCruelPlan.Core;
using System;

namespace _05.MordorCruelPlan
{
    public class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
