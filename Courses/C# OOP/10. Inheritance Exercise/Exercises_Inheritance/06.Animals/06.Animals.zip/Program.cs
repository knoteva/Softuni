﻿using _06.Animals.Core;
using System;

namespace _06.Animals
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
