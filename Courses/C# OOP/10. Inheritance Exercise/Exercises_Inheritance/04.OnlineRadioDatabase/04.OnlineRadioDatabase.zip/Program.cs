﻿using _04.OnlineRadioDatabase.Core;
using System;

namespace _04.OnlineRadioDatabase

{
    public class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
