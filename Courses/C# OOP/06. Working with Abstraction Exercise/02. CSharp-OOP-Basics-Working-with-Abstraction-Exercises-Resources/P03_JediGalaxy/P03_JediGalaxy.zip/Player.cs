﻿namespace P03_JediGalaxy
{
    public class Player
    {
        private int row;
        private int col;

        public int Row { get => row; set => row = value; }
        public int Col { get => col; set => col = value; }
    }
}
